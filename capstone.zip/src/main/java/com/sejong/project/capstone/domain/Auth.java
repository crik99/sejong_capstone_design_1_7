package com.sejong.project.capstone.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Auth {
    String id;
    String autority;
}
