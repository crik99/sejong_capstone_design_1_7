package com.sejong.project.capstone.domain;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Building {
    int id;
    String name;
}

