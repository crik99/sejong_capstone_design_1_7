package com.sejong.project.capstone.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Lecture {

    long id;
    String majorcode;
    String lecturename;
    int credit;
    String course;

}
