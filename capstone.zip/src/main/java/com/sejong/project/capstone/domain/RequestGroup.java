package com.sejong.project.capstone.domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;

@Getter
@Setter
@NoArgsConstructor
public class RequestGroup{
    int atime;
    String course;
}
