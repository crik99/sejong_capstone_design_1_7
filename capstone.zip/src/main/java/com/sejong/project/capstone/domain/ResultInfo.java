package com.sejong.project.capstone.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResultInfo {
    int no;
    String major;
    String lecture;
    String lecturer;
    String credit;
    String classroom;
    String time;

}
