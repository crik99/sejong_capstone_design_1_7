package com.sejong.project.capstone.domain.enums;

public enum UserAuth {
}
