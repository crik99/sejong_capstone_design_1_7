package com.sejong.project.capstone.mapper;

public interface StatisticMapper {

}